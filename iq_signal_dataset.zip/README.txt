Synthetic IQ dataset for the SIH signal analysis prototype.
IQ format: float32 interleaved I,Q,I,Q,...
Sample rate: 2,000,000 Hz
Modulations: BPSK, QPSK, 8PSK, QAM16, 2FSK
SNR: 0, 10, 20, 30 dB
Frequency offset: 25 kHz
See metadata.csv for file labels.
